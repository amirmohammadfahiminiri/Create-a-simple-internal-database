﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Processing
    {
        string dataString;
        static void StarsLine(int count)
        {
            for (int i = 0; i < count; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
        }
        string Content(string dataString)
        {
            this.dataString = dataString;
            return this.dataString;
        }
        string Content()
        {
            dataString = "Student ID;Name;Field of Study;Age;Gender\r\n" +
                "4002164016;Amirmohammad Fahimi Niri;computer engineering;21;male\r\n" +
                "4002164015;Vahid Hagigatdoost;computer engineering;40;male\r\n" +
                "3992164019;Amirreza Tavakkoli;computer engineering;24;male\r\n" +
                "She is not an student!;Angelina jolie;actress;48;female";
            return dataString;
        }
        void WriteSomeContents(FileStream fs)
        {
            byte[] info = new UTF8Encoding(true).GetBytes(Content());
            fs.Write(info, 0, info.Length);
        }
        public void CreateOrOpenFile(string path)
        {
            FileStream fs = new FileStream(path, FileMode.OpenOrCreate);
            WriteSomeContents(fs);
            fs.Close();
        }
        public static void desires(string desiredIndex, string path)
        {
            string[] firstLineAraay;
            string[] allLinesArray;
            string[] oneOfLinesArray;
            string oneOfLinesStr;
            string[] desiredIndexInPerLineArray;
            StarsLine(32);
            allLinesArray = File.ReadAllLines(path);
            firstLineAraay = allLinesArray[0].Split(';');
            for (int i = 0; i < firstLineAraay.Length; i++)
            {
                if (firstLineAraay[i] == desiredIndex)
                {
                    desiredIndexInPerLineArray = new string[allLinesArray.Length];
                    for (int k = 1; k < allLinesArray.Length; k++)
                    {
                        oneOfLinesStr = allLinesArray[k];
                        oneOfLinesArray = oneOfLinesStr.Split(';');
                        desiredIndexInPerLineArray[k] = oneOfLinesArray[i];
                    }
                    for (int l = 1; l < desiredIndexInPerLineArray.Length; l++)
                    {
                        Console.WriteLine(desiredIndexInPerLineArray[l]);
                    }
                    break;
                }
                else
                {
                    continue;
                }
            }
            StarsLine(32);
        }
    }
}
