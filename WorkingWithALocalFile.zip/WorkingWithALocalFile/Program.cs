﻿using System.IO;
using System.Linq.Expressions;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Processing pr = new Processing();
            Console.WriteLine("\tIf you want to Close, just press the Enter.");
            while(!ProgramLife.Finish())
            {
                string desiredIndex = "";
                //string path = "D:\\Users\\Home\\Desktop\\TextFileForConsoleApp4.txt";
                //string _path = "D:\\Users\\Home\\Desktop\\TextFileForConsoleApp4.csv";
                string path = "TextFileForConsoleApp4.txt";
                pr.CreateOrOpenFile(path);
                Console.Write("Enter a desire (Student ID, Name, Field of Study, Age, Gender): ");
                desiredIndex = Console.ReadLine();
                SwichCase.Swich(desiredIndex, path);
            }
        }
    }
}