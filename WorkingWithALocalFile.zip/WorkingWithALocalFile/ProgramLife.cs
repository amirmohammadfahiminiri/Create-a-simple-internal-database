﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class ProgramLife
    {
        static bool finishProgram = false;
        public static bool Finish()
        {
            return finishProgram;
        }
        public static void Finish(bool finish)
        {
            finishProgram = finish;
        }
    }
}
