﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class SwichCase
    {
        public static void Swich(string desiredIndex, string path)
        {
            desiredIndex = desiredIndex.ToLower();
            switch (desiredIndex)
            {
                case "student id":
                    desiredIndex = "Student ID";
                    Processing.desires(desiredIndex, path);
                    break;
                case "name":
                    desiredIndex = "Name";
                    Processing.desires(desiredIndex, path);
                    break;
                case "field of study":
                    desiredIndex = "Field of Study";
                    Processing.desires(desiredIndex, path);
                    break;
                case "age":
                    desiredIndex = "Age";
                    Processing.desires(desiredIndex, path);
                    break;
                case "gender":
                    desiredIndex = "Gender";
                    Processing.desires(desiredIndex, path);
                    break;
                case "":
                    ProgramLife.Finish(true);
                    break;
                default:
                    Console.Beep();
                    Console.WriteLine("False Input! :(");
                    break;
            }
        }
}
}
